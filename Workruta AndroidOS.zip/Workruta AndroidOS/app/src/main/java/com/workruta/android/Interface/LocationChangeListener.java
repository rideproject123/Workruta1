package com.workruta.android.Interface;

import androidx.appcompat.app.AppCompatActivity;

public interface LocationChangeListener {
    void locationChanged(AppCompatActivity appCompatActivity);
}
