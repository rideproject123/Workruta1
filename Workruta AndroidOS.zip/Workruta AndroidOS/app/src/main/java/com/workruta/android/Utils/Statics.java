package com.workruta.android.Utils;

import org.json.JSONArray;

public class Statics {

    public static String activityName = null;
    public static JSONArray ALL_RUNNING_ACTIVITIES = new JSONArray();

}
