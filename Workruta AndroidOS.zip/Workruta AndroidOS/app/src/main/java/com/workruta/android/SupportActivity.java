package com.workruta.android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SupportActivity extends SharedCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);
    }
}